<?php
include "koneksi.php";
$comodity = isset($_GET['comodity']) ? $_GET['comodity']:null;
$date = isset($_GET['date']) ? $_GET['date']:null;
$status = isset($_GET['status']) ? $_GET['status']:null;

$ruser = mysqli_query($con,"SELECT Date,Prediction FROM `prediksi` WHERE Date='$date'");  
$j = mysqli_num_rows($ruser);
$result=array();
if($j>0 and $comodity==7){
  while($row=mysqli_fetch_object($ruser)) {
  
    array_push($result,array(
      'harga'=>$row->Prediction
    ));
    }
  
  $response = array(
    'results' => $result,
    'status' => 1);
}else{
    array_push($result,array(
        'harga'=>0
      ));
  $response = array(
    'results' => $result,
    'status' => 0);
}
    

echo json_encode($response);
?>