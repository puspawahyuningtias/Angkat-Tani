<?php
include "koneksi.php";
$comodity = isset($_GET['comodity']) ? $_GET['comodity']:null;
$date = isset($_GET['date']) ? $_GET['date']:null;
$status = isset($_GET['status']) ? $_GET['status']:null;
if($status==true){
    if ($comodity==0) $ruser = mysqli_query($con,"SELECT tanggal, beras FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==1) $ruser = mysqli_query($con,"SELECT tanggal, beras_kualitas_bawah_satu_kg FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==2) $ruser = mysqli_query($con,"SELECT tanggal, beras_kualitas_bawah_dua_kg FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==3) $ruser = mysqli_query($con,"SELECT tanggal, beras_kualitas_medium_satu_kg FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==4) $ruser = mysqli_query($con,"SELECT tanggal, beras_kualitas_medium_dua_kg FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==5) $ruser = mysqli_query($con,"SELECT tanggal, beras_kualitas_super_satu_kg FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==6) $ruser = mysqli_query($con,"SELECT tanggal, beras_kualitas_super_dua_kg FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==7) $ruser = mysqli_query($con,"SELECT tanggal, bawang_merah FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==8) $ruser = mysqli_query($con,"SELECT tanggal, bawang_merah_ukuran_sedang_kg FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==9) $ruser = mysqli_query($con,"SELECT tanggal, bawang_putih FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==10) $ruser = mysqli_query($con,"SELECT tanggal, bawang_putih_ukuran_sedang_kg FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==11) $ruser = mysqli_query($con,"SELECT tanggal, cabai_merah FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==12) $ruser = mysqli_query($con,"SELECT tanggal, cabai_merah_besar_kg FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==13) $ruser = mysqli_query($con,"SELECT tanggal, cabai_merah_keriting_kg FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==14) $ruser = mysqli_query($con,"SELECT tanggal, cabai_rawit FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==15) $ruser = mysqli_query($con,"SELECT tanggal, cabai_rawit_hijau_kg FROM `harga_pangan` WHERE tanggal='$date'");  
    else if ($comodity==16) $ruser = mysqli_query($con,"SELECT tanggal, cabai_rawit_merah_kg FROM `harga_pangan` WHERE tanggal='$date'");  
    $j = mysqli_num_rows($ruser);
    $result=array();
    if($j>0){
      while($row=mysqli_fetch_object($ruser)) {
        if($comodity==0){
        array_push($result,array(
          'harga'=>$row->beras
        ));
        }else if($comodity==1){
            array_push($result,array(
                'harga'=>$row->beras_kualitas_bawah_satu_kg
              ));
        }else if($comodity==2){
            array_push($result,array(
                'harga'=>$row->beras_kualitas_bawah_dua_kg
              ));
        }else if($comodity==3){
            array_push($result,array(
                'harga'=>$row->beras_kualitas_medium_satu_kg
              ));
        }else if($comodity==4){
            array_push($result,array(
                'harga'=>$row->beras_kualitas_medium_dua_kg
              ));
        }else if($comodity==5){
            array_push($result,array(
                'harga'=>$row->beras_kualitas_super_satu_kg
              ));
        }else if($comodity==6){
            array_push($result,array(
                'harga'=>$row->beras_kualitas_super_dua_kg
              ));
        }else if($comodity==7){
            array_push($result,array(
                'harga'=>$row->bawang_merah
              ));
        }else if($comodity==8){
            array_push($result,array(
                'harga'=>$row->bawang_merah_ukuran_sedang_kg
              ));
        }else if($comodity==9){
            array_push($result,array(
                'harga'=>$row->bawang_putih
              ));
        }else if($comodity==10){
            array_push($result,array(
                'harga'=>$row->bawang_putih_ukuran_sedang_kg
              ));
        }else if($comodity==11){
            array_push($result,array(
                'harga'=>$row->cabai_merah
              ));
        }else if($comodity==12){
            array_push($result,array(
                'harga'=>$row->cabai_merah_besar_kg
              ));
        }else if($comodity==13){
            array_push($result,array(
                'harga'=>$row->cabai_merah_keriting_kg
              ));
        }else if($comodity==14){
            array_push($result,array(
                'harga'=>$row->cabai_rawit
              ));
        }else if($comodity==15){
            array_push($result,array(
                'harga'=>$row->cabai_rawit_hijau_kg
              ));
        }else if($comodity==16){
            array_push($result,array(
                'harga'=>$row->cabai_rawit_merah_kg
              ));
        }
      }
      $response = array(
        'results' => $result,
        'status' => 1);
    }else{
        array_push($result,array(
            'harga'=>0
          ));
      $response = array(
        'results' => $result,
        'status' => 0);
    }
        
    
    echo json_encode($response);
}else if($status==false){

}

?>