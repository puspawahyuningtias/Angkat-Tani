<?php
include "koneksi.php";
$year = date('Y');
$yearmin = $year-1;
$comodity = isset($_GET['comodity']) ? $_GET['comodity']:null;
// if ($comodity==1) $ruser = mysqli_query($con,"SELECT DISTINCT LEFT(tanggal,7) as tanggal, MONTH(tanggal) as bulan, LEFT(tanggal,4) as tahun, beras FROM `data` WHERE RIGHT(tanggal,5) = '04-01' or RIGHT(tanggal,5) = '08-01' or RIGHT(tanggal,5) = '12-01'");  
if ($comodity==0) $ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, beras FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==1)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, beras_kualitas_bawah_satu_kg  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==2)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, beras_kualitas_bawah_dua_kg  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==3)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, beras_kualitas_medium_satu_kg  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==4)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, beras_kualitas_medium_dua_kg  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==5)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, beras_kualitas_super_satu_kg  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==6)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, beras_kualitas_super_dua_kg  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==7)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, bawang_merah  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==8)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, bawang_merah_ukuran_sedang_kg  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==9)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, bawang_putih  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==10)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, bawang_putih_ukuran_sedang_kg  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==11)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, cabai_merah  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==12)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, cabai_merah_besar_kg  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==13)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, cabai_merah_keriting_kg  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==14)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, cabai_rawit  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==15)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, cabai_rawit_hijau_kg  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
else if($comodity==16)$ruser = mysqli_query($con,"SELECT DISTINCT YEAR(tanggal) as tahun, MONTH(tanggal) as bulan, cabai_rawit_merah_kg  FROM `harga_pangan` WHERE YEAR(tanggal) = '$yearmin' GROUP by MONTH(tanggal) DESC");  
$j = mysqli_num_rows($ruser);
$result=array();
if($j>0){
  while($row=mysqli_fetch_object($ruser)) {
    if($comodity==0){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->beras
    ));
  }else if($comodity==1){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->beras_kualitas_bawah_satu_kg 
    ));
  }else if($comodity==2){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->beras_kualitas_bawah_dua_kg 
    ));
  }else if($comodity==3){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->beras_kualitas_medium_satu_kg 
    ));
  }else if($comodity==4){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->beras_kualitas_medium_dua_kg 
    ));
  }else if($comodity==5){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->beras_kualitas_super_satu_kg 
    ));
  }else if($comodity==6){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->beras_kualitas_super_dua_kg 
    ));
  }else if($comodity==7){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->bawang_merah 
    ));
  }else if($comodity==8){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->bawang_merah_ukuran_sedang_kg 
    ));
  }else if($comodity==9){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->bawang_putih 
    ));
  }else if($comodity==10){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->bawang_putih_ukuran_sedang_kg 
    ));
  }else if($comodity==11){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->cabai_merah 
    ));
  }else if($comodity==12){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->cabai_merah_besar_kg 
    ));
  }else if($comodity==13){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->cabai_merah_keriting_kg 
    ));
  }else if($comodity==14){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->cabai_rawit 
    ));
  }else if($comodity==15){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->cabai_rawit_hijau_kg 
    ));
  }else if($comodity==16){
    array_push($result,array(
      'tahun'=>$row->tahun,
      'bulan'=>$row->bulan,
      'harga'=>$row->cabai_rawit_merah_kg 
    ));
  }
  }
  $response = array(
    'results' => $result,
    'status' => 1);
}else{
  $response = array(
    'results' => "tidak ditemukan !",
    'status' => 0);
}
    

echo json_encode($response);
?>